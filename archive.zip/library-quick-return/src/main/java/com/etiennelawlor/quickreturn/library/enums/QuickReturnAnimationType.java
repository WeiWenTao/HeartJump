package com.etiennelawlor.quickreturn.library.enums;

/**
 * Created by etiennelawlor on 7/10/14.
 */
public enum QuickReturnAnimationType {
    TRANSLATION_SIMPLE,
    TRANSLATION_SNAP,
    TRANSLATION_ANTICIPATE_OVERSHOOT
}