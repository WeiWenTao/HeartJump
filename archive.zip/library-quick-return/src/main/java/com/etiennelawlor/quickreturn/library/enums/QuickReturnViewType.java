package com.etiennelawlor.quickreturn.library.enums;

/**
 * Created by etiennelawlor on 7/10/14.
 */
public enum QuickReturnViewType {
    HEADER,
    FOOTER,
    BOTH,
    GOOGLE_PLUS,
    TWITTER
}