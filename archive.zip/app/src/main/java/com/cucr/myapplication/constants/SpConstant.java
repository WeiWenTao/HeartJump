package com.cucr.myapplication.constants;

/**
 * 记录了一些代码中会公用的常量
 */

public class SpConstant {
    public static final String SP_NAME = "config";
    public static final String IS_FIRST_RUN = "is_first_run";
}
